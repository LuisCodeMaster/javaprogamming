package AvaliacaoLuis;

public interface Ipagamentos {

	public double Calculo () ;
}